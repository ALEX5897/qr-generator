import { RenderingContext2D } from '../types';
import RenderedElement from './RenderedElement';
export default class SymbolElement extends RenderedElement {
    type: string;
    render(_: RenderingContext2D): void;
}
//# sourceMappingURL=SymbolElement.d.ts.map