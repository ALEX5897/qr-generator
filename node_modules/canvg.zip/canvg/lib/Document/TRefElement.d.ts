import TextElement from './TextElement';
export default class TRefElement extends TextElement {
    type: string;
    getText(): string;
}
//# sourceMappingURL=TRefElement.d.ts.map