import AnimateElement from './AnimateElement';
export default class AnimateColorElement extends AnimateElement {
    type: string;
    calcValue(): string;
}
//# sourceMappingURL=AnimateColorElement.d.ts.map