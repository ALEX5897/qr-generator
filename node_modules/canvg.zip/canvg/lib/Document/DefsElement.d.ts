import Element from './Element';
export default class DefsElement extends Element {
    type: string;
    render(): void;
}
//# sourceMappingURL=DefsElement.d.ts.map