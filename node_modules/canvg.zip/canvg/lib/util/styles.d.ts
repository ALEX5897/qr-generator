/**
 * Measure selector specificity.
 * @param selector - Selector to measure.
 * @returns Specificity.
 */
export declare function getSelectorSpecificity(selector: string): string;
//# sourceMappingURL=styles.d.ts.map