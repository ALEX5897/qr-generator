var assertClassBrand = require("./assertClassBrand.js");
function _classPrivateSetter(s, r, a, t) {
  return r(assertClassBrand(s, a), t), t;
}
module.exports = _classPrivateSetter, module.exports.__esModule = true, module.exports["default"] = module.exports;