'use strict';
var parent = require('../../stable/array/unshift');

module.exports = parent;
