'use strict';
var parent = require('../../stable/array/find-index');

module.exports = parent;
