'use strict';
var parent = require('../../stable/array/splice');

module.exports = parent;
