export { __metadata as default } from 'tslib'
